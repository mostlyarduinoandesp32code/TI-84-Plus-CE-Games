Zombie Chase CE
Spenceboy98

This program requires the libraries provided here: https://github.com/CE-Programming/libraries/releases/latest

This is a port of my Prizm game Zombie Chase to the CE! It has the same gameplay, but now its got improved graphics! 

In this game you are a white dot attempting to survive the zombie apocalypse. You must collect red health packs and avoid green zombies, or you will die. Good luck! Once "bitten" by a zombie, you become infected! Health decreases after you've been bitten, so you have less time to get points. Also, health packs give more health after being bitten.
Use arrows to move, and that's about it for the controls (so far). :P

This version has better graphics to match the "extra gory" FAIL screen, an improved font implementation, and the bug that crashed a lot of peoples calculators should still be gone! Health packs are now shaped like a plus, and zombies have a different shape with more color. I hope you enjoy!

This has also been updated with the latest libraries. Everything else should be the same, but let me know if you have any issues.

Special thanks to MateoConLechuga for the C SDK and for helping optimize my code! Also, thanks to him for putting up with my constant questions and n00b mistakes.

If you have any issues or bug reports, please post in the appropriate thread. I'll do my best to keep this project updated and as bug free as I can. Thanks for your support!
https://www.cemetech.net/forum/viewtopic.php?p=246677
